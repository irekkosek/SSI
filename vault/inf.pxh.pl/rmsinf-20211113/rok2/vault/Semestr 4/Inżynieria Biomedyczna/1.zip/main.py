import pandas
import datetime


PERIODS = [
    "Autumn_2015",
    "Spring_2016", "Autumn_2016",
    "Spring_2017", "Autumn_2017",
    "Spring_2018", "Autumn_2018",
    "Spring_2019", "Autumn_2019"]


def get_date(str_date):
    try:
        date = datetime.datetime.strptime(str_date, "%Y.%m.%d")
    except ValueError:
        try:
            date = datetime.datetime.strptime(str_date, "%Y-%m-%d")
        except ValueError:
            try:
                date = datetime.datetime.strptime(str_date, "%d-%m-%Y")
            except ValueError:
                date = datetime.datetime.strptime(str_date, "%d.%m.%Y")
    return date


def get_period(date):
    season = "wiosna" if date.month < 6 else "jesień"
    return "{}_{}".format(season, date.year)


def create_cols(data_frame, sec_data_frame):
    new_df = pandas.DataFrame()
    record_periods = []
    period_number = 0
    for key in data_frame:
        period_number = 0
        for data in data_frame[key]:
            if key == "id":
                new_df[key] = [data,]
                break
            elif key == "DataBadania":
                date = get_date(data)
                record_periods.append(get_period(date))
            else:
                assert record_periods is not []
                while period_number < len(PERIODS):
                    dt = PERIODS[period_number]
                    header = key + "_" + dt
                    period_number += 1
                    if dt in record_periods:
                        new_df[header] = [data, ]
                        break
                    else:
                        new_df[header] = " "
        if key == "id":
            continue
        elif key == "DataBadania":
            continue
        while period_number < len(PERIODS):
            dt = PERIODS[period_number]
            header = key + "_" + dt
            period_number += 1
            new_df[header] = " "

    for key in sec_data_frame:
        period_number = 0
        for data in sec_data_frame[key]:
            if key == "id":
                break
            elif key == "DataBadania":
                str_date = data.split(" ")[0][:-1]
                date = get_date(str_date)
                record_periods.append(get_period(date))
            elif key in ["DateOfBirth", "Sex","Age"]:
                new_df[key] = [data, ]
                break
            else:
                assert record_periods is not []
                while period_number < len(PERIODS):
                    dt = PERIODS[period_number]
                    header = key + "_" + dt
                    period_number += 1
                    if dt in record_periods:
                        new_df[header] = [data, ]
                        break
                    else:
                        new_df[header] = " "
        if key == "id":
            continue
        elif key == "DataBadania":
            continue
        while period_number < len(PERIODS):
            dt = PERIODS[period_number]
            header = key + "_" + dt
            period_number += 1
            new_df[header] = " "
    return new_df


def run():
    csv = pandas.read_csv("dane_antropo_.csv")
    sec_csv = pandas.read_csv("dane_inbody_.csv")

    sec_csv = sec_csv.sort_values("id")
    csv = csv.sort_values("id")
    del csv['data.badania']
    del sec_csv['data.badania']
    del sec_csv['Id']

    ids = csv.drop_duplicates(['id'])['id']

    frames = []

    for identity in ids:
        one_patient = csv[csv['id'] == identity]
        one_patient_more_data = sec_csv[sec_csv['id'] == identity]
        one_patient = one_patient.drop_duplicates("DataBadania").sort_values("DataBadania")
        one_patient_more_data = one_patient_more_data.drop_duplicates("DataBadania").sort_values("DataBadania")

        frames.append(create_cols(one_patient, one_patient_more_data))

    final_frame = pandas.concat(frames)
    final_frame.to_csv("result.csv")


if __name__ == "__main__":
    run()
